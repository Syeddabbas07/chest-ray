# Chest Ray

Web app for pneumonia detection using chest X-rays.