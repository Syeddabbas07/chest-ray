# Define Flask routes

from app import app

@app.route('/')
def home():
    return 'Welcome to Chest Ray!'