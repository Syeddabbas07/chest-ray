# Configuration file

DEBUG = True